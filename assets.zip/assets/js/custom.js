function validateEmailfun(e) {
    //alert(e.target.id);
     var email = e.target.value;
     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     if (!filter.test(email)) {
       $("." + e.target.id).text("Please provide a valid email address");
       email.focus;
       //return false;
    } else {
        $("." + e.target.id).text("");
    }
 }
 
 /************* Age Calculation ******************/
 
 
function handler(e){
     //alert(e.target.id);
     var today = new Date(e.target.value);
     var month_diff = Date.now() - today.getTime();
     var age_dt = new Date(month_diff); 
     var year = age_dt.getUTCFullYear();
     var age = Math.abs(year - 1970);
     $('.' + e.target.id).val(age);
}
/*******flag-phon-code********/

var telInput = $(".phone");

        // initialise plugin
        telInput.intlTelInput({
        preferredCountries: ["in" ],
          separateDialCode: true,
          utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.4/js/utils.js"
        });